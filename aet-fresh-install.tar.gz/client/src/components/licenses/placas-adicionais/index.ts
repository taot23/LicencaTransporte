export * from './campo-placa-adicional';
export * from './placa-adicional-item';